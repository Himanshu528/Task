const express = require("express");
const router = express.Router();
const controller = require("../controller/techcontroller");
const mentorcontroller = require("../controller/mentorProject");

router.post("/addtech" , controller.addTechnology);
router.post("/signup" , controller.Signup);
router.post("/login" , controller.Login);
router.post("/addProject" , mentorcontroller.adminProject);



module.exports = router;