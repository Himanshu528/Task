const mongoose = require("mongoose");
const projectSchema = mongoose.Schema;


const ProjectSchema = new projectSchema({

  project_name: {
    type: Array,
    required: true,

  },
  project_owner: {
    type: Array,

  },

  Owner_emailId: {
    type: Array,
   // required: true,
    
    match: [
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
      "Please add a valid email!",
    ],
  },

  candidates: {
    type: Array,

  },
  startDate: {
    type: Date,
    default: Date.now,
  },
  endDate: {
    type: Date,
    default: Date.now,

  },
  department: {
    type: String,
    //required: true,
  },
  status: {
    type: String,
    default:"Waiting for allocation"
  },
  designation : {
    type : String,
   // require : true,
  },
  projectTitle : {
    type: String,
    default: "How we'll collaborate"
  },
  projectDescription :{
    type : String,
    //require: true,
    default: "Welcome your team and set the tone for how you'll work together in new project. Add meeting details, communication channels, and other important information."
  },
  createdAt : {
    type : Date
  }
});

module.exports = mongoose.model("project", ProjectSchema);