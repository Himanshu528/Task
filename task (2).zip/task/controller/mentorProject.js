require("dotenv").config();
const Project = require("../models/addProjectmodel");


const adminProject = async (req, res) => {
    try {
        var result = false;
        const verifiedUser = req.user;
        const { project_name, project_owner, candidates, startDate, endDate, department, Owner_emailId,projectTitle, projectDescription}  = req.body;

    //project_name
    const checkPorjectname = await Project.findOne({ project_name : project_name});
    if(checkPorjectname){
        return res.status(401).json({
            code : 401,
            status: false,
            message: "Project name is already exist",
            data: {}

        });
    }
       const project = Project({

            project_name : project_name,
            project_owner: project_owner,
            candidates: candidates,
            startDate: startDate,
            endDate: endDate,
            department: department,
            Owner_emailId: [...new Set(Owner_emailId)],
            projectDescription: projectDescription,
            projectTitle: projectTitle,
            createdAt : Date.now()
        })
        
        project.project_owner.forEach(item =>{
            
            project.candidates.forEach(item1 =>{
                if(item == item1){
                    return result = true
                     
                
                }
                
            })
    
        })
        if(result == true){
              return res.status(401).json({
                        code : 401,
                        status : false,
                        message : "Project Owner and candidates can't be same",
                        data :{}
                    
                    })
            

        }else{
            console.log(project)
        const projectDetails = await project.save();
        res.status(200).json({
            
            code : 200,
            status : true,
            message : "Project added successfully",
            data  : {projectDetails}
         })
        }
            
    }catch(error){
         res.status(400).json({
            code: 400,
             status: false,
              message: error.message, 
              data: {} 
        })
        
       
    }
};

module.exports = {adminProject};