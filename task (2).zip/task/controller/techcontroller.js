const express = require("express");
const multer = require("multer")
const moment = require("moment");
const path = require('path');
const dotenv = require("dotenv");
dotenv.config({ path: "./config.env" });
const bcrypt = require("bcrypt");
const { v4: uuid } = require("uuid");
const technology = require("../models/projectmodel");
const User = require("../models/usermodel");
const { generateJwt } = require("../helpers/jwt");

function isValidateEmail(Vemail) {
    const re =
        /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(Vemail).toLowerCase());
}
function CheckPassword(password) {
    const che =
        /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{6,15}$/g;
    return che.test((password));
}
function CheckUserName(name) {
    const che = /^[a-zA-Z0-9]{5,25}$/;
    return che.test((name));
}

function onlyNumbers(str) {
    return /^[0-9]+$/.test(str);
}


exports.Signup = async (req, res) => {
    try {
        var { userName, name, email, password, confirmPassword } = req.body

        userName = userName.toLowerCase()

        const userExists = await User.exists({ username: userName });

        if (userExists) {
            return res.status(400).send({
                statuscode: 400,
                status: "Failed",
                message: "UserName Already Exist",
                data: {},
            });
        }


        if (!CheckUserName(userName) || onlyNumbers(userName)) {
            return res.status(403).send({
                statuscode: 403,
                status: "Failed",
                message: "UserName must be between 5-25 Characters with AlphaNumeric Combinations,No Spaces & Special Characters allowed",
                data: {}
            });
        }

        if (!isValidateEmail(email)) {
            return res.status(401).send({
                statuscode: 401,
                status: "Failed",
                message: "Email Is Invalid",
                data: {},
            });
        }

        if (!CheckPassword(password)) {
            return res.status(403).send({
                statuscode: 403,
                status: "Failed",
                message: "Password must be at least 6 characters which include one uppercase, one lowercase, one special characters and one digit",
                data: {},
            });
        }

        if (password != confirmPassword) {
            return res.status(402).json({
                statuscode: 402,
                status: "Failed",
                message: "Passwords MisMatched",
                data: {},
            });
        }

        email = email.replace(/\s+/g, '');
        email = email.toLowerCase();

        var user = await User.findOne({ email: email });

        if (user) {
            return res.status(404).json({
                statuscode: 404,
                status: "Failed",
                message: "Email Is Already In Use",
                data: {},
            });
        }

        var hash = await User.hashPassword(password);

        var id = uuid(); //Generate unique id for the user.

        let newUser = new User({
            username: userName.toLowerCase(),
            userId: id,
            email: email,
            name: name,
            password: [hash],
            confirmPassword: hash,
           
        })
        await newUser.save();

        return res.status(200).json({
            statuscode: 200,
            status: "OK",
            message: "Registered Success",
            data: {},
        });
    } catch (error) {
        console.error("signup-error", error);
        return res.status(500).json({
            statuscode: 500,
            status: "Error",
            message: "Cannot Register",
            data: {
                error
            },
        });
    }
};

exports.Login = async (req, res) => {
    try {
        var { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: "Enter All Credentials Mandatory",
                data: {},
            });
        }
        if (!CheckUserName(email) && isValidateEmail(email)) {

            if (!isValidateEmail(email)) {

                return res.status(404).send({
                    statuscode: 404,
                    status: "Failed",
                    message: "Email Is Invalid",
                    data: {}
                });
            }

            email = email.replace(/\s+/g, '');
            email = email.toLowerCase();

            var user = await User.findOne({ email: email });

        } else {

            if (CheckUserName(email)) {

                console.log("USERNAME")
                email = email.toLowerCase();

                var user = await User.findOne({ username: email });

            } else {

                return res.status(406).send({
                    statuscode: 406,
                    status: "Failed",
                    message: "UserName Is Invalid",
                    data: {}
                });

            }
        }

        if (!user) {
            return res.status(402).json({
                statuscode: 402,
                status: "Not Found",
                message: "Account Not Found",
                data: {},
            });
        }

        const isValid = await User.comparePasswords(password, user.password[user.password.length - 1]);

        if (!isValid) {
            return res.status(401).json({
                statuscode: 401,
                status: "Failed",
                message: "Invalid Credentials",
                data: {},
            });
        }


        const { error, token } = await generateJwt(user.email, user.userId);

        if (error) {
            return res.status(501).json({
                statuscode: 501,
                status: "Error",
                message: "Couldn't create access token. Please try again later",
                data: {},
            });
        }

        return res.status(200).json({
            statuscode: 200,
            status: "OK",
            message: "User Logged In Successfully",
            accessToken: token,
            data: {
                userId: user.userId,
                email: user.email,
                name: user.name,
                userName: user.username,
            },
        });
    } catch (err) {
        console.error("Login error", err);
        return res.status(500).json({
            statuscode: 500,
            status: "Error",
            message: "Couldn't login. Please try again later.",
            data: {},
        });
    }
};

const storage = multer.diskStorage({
    destination: path.join(__dirname, './upload/images', moment().format('DD/MM/YYYY')),
    filename: (req, file, cb) => {
        return cb(null, `${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`)
    }
});
const upload = multer({
    storage: storage,

}).single('profile');

exports.addTechnology = async (req, res) => {
    upload(req, res, (err) => {
        if (err) {
            console.log(err);
        }
        else {
            let image = new technology({
                name: req.body.name,
                image: {
                    data: req.file.filename,
                    contentType: 'image/png'
                }
            });
            image.save().then(() => {
                res.status(200).json({
                    message: 'Image is uploaded on mongoDb and on the server',
                    profile_url: `http://localhost:3000/profile/${req.file.filename}`
                })
            }).catch((err) => {
                res.status(500).json({
                    message: 'Please try again, something went wrong'
                })
            })
        }

    })
}




