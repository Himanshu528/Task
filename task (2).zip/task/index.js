const express = require("express");
const app = express();
const mongoose = require("mongoose")
const bodyParser = require("body-parser")
const url = "mongodb+srv://Admin123:Admin123@cluster0.hoh9ymt.mongodb.net/?retryWrites=true&w=majority"

app.use(express.json())

mongoose.connect(url);
const con = mongoose.connection;

con.on("open" , ()=>{
    console.log("mongodb connected")
})

const route = require("./routes/techroutes");
app.use("/techRoute" , route)
app.use("/user", route)
app.use("/mentor", route)

app.listen("3000" , ()=>{
    console.log("server run on port 3000")
})